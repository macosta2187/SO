#!/bin/bash

# Script de Operador de Centro de Cómputos

while true; do
    clear  # Limpiar la pantalla

    # Mostrar el menú de opciones
    echo "Menú de Operador de Centro de Cómputos"
    echo "1. Ver estado de los servidores"
    echo "2. Reiniciar un servidor"
    echo "3. Ver registros de actividad"
    echo "4. Salir"

    
    read -p "Ingrese el número de opción deseada: " opcion

    case $opcion in
        1)  # Ver estado de los servidores
            echo "Estado de los servidores:"
            # Utiliza Ansible para verificar el estado de los servidores.
            ansible all -m ping
            ;;
        2)  # Reiniciar un servidor
            read -p "Ingrese el nombre de host del servidor que desea reiniciar: " host_servidor
            # Utiliza Ansible para reiniciar el servidor.
            ansible $host_servidor -m reboot
            ;;
        3)  # Ver registros de actividad
            read -p "Ingrese el nombre de host del servidor para ver registros de actividad: " host_servidor
            # Utiliza Ansible para consultar registros de actividad (por ejemplo, registros de eventos del sistema).
            ansible $host_servidor -m shell -a "tail /var/log/syslog"
            ;;
        4)  # Salir
            echo "Saliendo del programa."
            exit 0
            ;;
        *)  # Opción no válida
            echo "Opción no válida. Por favor, elija una opción válida."
            ;;
    esac

    
    read -p "Presione Enter para continuar..."
done
