#!/bin/bash


function mostrar_registros_exitosos() {
    echo "Registros de intentos de inicio de sesión exitosos:"
    journalctl -t sshd | grep "Accepted password\|Accepted publickey"
}


function mostrar_registros_fallidos() {
    echo "Registros de intentos de inicio de sesión fallidos:"
    journalctl -t sshd | grep "Failed password\|Failed publickey"
}

# Función principal del script
function main() {
    while true; do
        clear  # Limpiar la pantalla

        # Mostrar el menú de opciones
        echo "Menú de acceso a registros de inicio de sesión"
        echo "1. Mostrar intentos de inicio de sesión exitosos"
        echo "2. Mostrar intentos de inicio de sesión fallidos"
        echo "3. Salir"

       
        read -p "Ingrese el número de opción deseada: " opcion

        case $opcion in
            1)  # Mostrar registros exitosos
                mostrar_registros_exitosos
                ;;
            2)  # Mostrar registros fallidos
                mostrar_registros_fallidos
                ;;
            3)  # Salir
                echo "Saliendo del programa."
                exit 0
                ;;
            *)  # Opción no válida
                echo "Opción no válida. Por favor, elija una opción válida."
                ;;
        esac

       
        read -p "Presione Enter para continuar..."
    done
}


main
